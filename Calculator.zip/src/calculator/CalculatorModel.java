
package calculator;


public class CalculatorModel {
    private int result;
    
    public void addition(int num1, int num2){
        result = num1 + num2;
    }
    public int returnResult(){
        return result;
    }
}
