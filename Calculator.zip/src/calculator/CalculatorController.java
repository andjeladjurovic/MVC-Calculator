package calculator;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorController {
    private CalculatorView theView;
    private CalculatorModel theModel;
    
    public CalculatorController(CalculatorView theView, CalculatorModel theModel){
        this.theView = theView;
        this.theModel = theModel;
        
        this.theView.AddCalculationListener(new CalculateListener());
    }

    class CalculateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            int num1, num2 = 0;
            try{
                num1 = theView.returnFirstNumber();
                num2 = theView.returnSecondNumber();
                
                theModel.addition(num1, num2);
                theView.setResult(theModel.returnResult());
            }catch(NumberFormatException ex){
                theView.DisplayErrorMessage("You need to enter two integers");
            }
        }

        
    }
}
