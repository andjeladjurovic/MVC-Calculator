
package calculator;

import java.awt.event.ActionListener;
import javax.swing.*;

public class CalculatorView extends JFrame {
    
    private JTextField num1 = new JTextField(10);
    private JLabel additionLab = new JLabel("+");
    private JTextField num2 = new JTextField(10);
    private JButton sumBtn = new JButton("SUM");
    private JTextField result = new JTextField(10);
    
    CalculatorView(){
        JPanel calcPanel = new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 300);
        
        calcPanel.add(num1);
        calcPanel.add(additionLab);
        calcPanel.add(num2);
        calcPanel.add(sumBtn);
        calcPanel.add(result);
        
        this.add(calcPanel);
    }
    public int returnFirstNumber(){
        return Integer.parseInt(num1.getText());
    }
    public int returnSecondNumber(){
        return Integer.parseInt(num2.getText());
    }
    public int returnResult(){
        return Integer.parseInt(result.getText());
    }
    public void setResult(int res){
        result.setText(Integer.toString(res));
    }
    //kada se klikne na dugme pozivamo kontrolera da ga obavestimo
    //jer smo u View-u, a to se tu ne radi
    void AddCalculationListener(ActionListener listen){
        sumBtn.addActionListener(listen);
    }
    void DisplayErrorMessage(String errorMessage){
        JOptionPane.showMessageDialog(this, errorMessage);
    }
}
